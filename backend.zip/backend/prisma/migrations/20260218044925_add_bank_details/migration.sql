-- AlterTable
ALTER TABLE "employees" ADD COLUMN     "bank_account_number" TEXT,
ADD COLUMN     "bank_name" TEXT,
ADD COLUMN     "ifsc_code" TEXT;
