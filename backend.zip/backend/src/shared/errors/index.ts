export { DomainError, type DomainErrorOptions } from './domain.error';
export { InfrastructureError } from './infrastructure.error';
